class Program
{
    static void Main()
    {
        Console.Write("Message : ");
        string message = Console.ReadLine()!;

        Console.Write("Cle : ");
        string cle = Console.ReadLine()!;

        Console.Clear();

        Vigenere vigenere = new();

        // Affichage de la grille
        Console.WriteLine("Test 1 : Grille\n");
        vigenere.AfficherGrille();

        Console.WriteLine("\nTest 2 : Cryptage lettre par lettre\n");
        vigenere.VoirCryptage(message, cle);

        Console.WriteLine("\nTest 3 : Cryptage message\n");

        vigenere.Initialiser(message, cle);
        string crypte = vigenere.DonnerMessageCrypte();

        Console.WriteLine($"Message original : {message}");
        Console.WriteLine($"Cle : {cle}");
        Console.WriteLine($"Message crypte : {crypte}\n");

        // Test avec une autre clé
        Console.WriteLine("Test 4 : Cryptage avec autre cle\n");
        Console.Write("Autre cle : ");

        string incorrect = Console.ReadLine()!;
        vigenere.Initialiser(message, incorrect);
        string crypte2 = vigenere.DonnerMessageCrypte();

        Console.WriteLine($"\nMessage original : {message}");
        Console.WriteLine($"Cle : {incorrect}");
        Console.WriteLine($"Message crypte : {crypte2}\n");

        Console.WriteLine("Test 5 : Decryptage\n");
        vigenere.Initialiser(crypte, cle);
        string decode = vigenere.DonnerMessageClair();
        Console.WriteLine($"Message crypte : {crypte}");
        Console.WriteLine($"Cle : {cle}");
        Console.WriteLine($"Message decode : {decode}");
        bool ok = decode == message;
        Console.WriteLine($"\nVerif : {(ok ? "OK" : "ECHEC")}\n");

        Console.WriteLine("Test 6 : Decryptage lettre par lettre");
        vigenere.VoirDecryptage(crypte, cle);

        Console.ReadKey();
    }
}
