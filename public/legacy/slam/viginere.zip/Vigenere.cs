class Vigenere
{
    private readonly char[,] grille;
    private string message;
    private string cle;

    public Vigenere()
    {
        grille = new char[26, 26];
        message = "";
        cle = "";

        InitialiserGrille();
    }

    public Vigenere(string Cle)
    {
        grille = new char[26, 26];
        message = "";
        cle = Cle.ToLower();

        InitialiserGrille();
    }

    public Vigenere(string Message, string Cle)
    {
        grille = new char[26, 26];
        message = Message.ToLower();
        cle = Cle.ToLower();

        InitialiserGrille();
    }

    public void Initialiser(string message, string cle)
    {
        this.message = message.ToLower();
        this.cle = cle.ToLower();
    }

    public void InitialiserGrille()
    {
        int taille = grille.GetLength(0);
        for (int ligne = 0; ligne < taille; ligne++)
        {
            for (int colonne = 0; colonne < taille; colonne++)
            {
                int codeAscii = ((colonne + ligne) % taille) + 97; // 97 = 'a'
                grille[ligne, colonne] = (char)codeAscii;
            }
        }
    }

    public void AfficherGrille()
    {
        int taille = grille.GetLength(0);

        Console.Write("   ");
        for (int i = 0; i < taille; i++)
        {
            Console.Write((char)(97 + i) + " ");
        }
        Console.WriteLine();
        Console.WriteLine();

        for (int ligne = 0; ligne < taille; ligne++)
        {
            Console.Write((char)(97 + ligne) + "  ");

            for (int colonne = 0; colonne < taille; colonne++)
            {
                Console.Write(grille[ligne, colonne] + " ");
            }
            Console.WriteLine();
        }
    }

    public void VoirCryptage(string msg, string key)
    {
        Console.WriteLine($"Message : {msg}");
        Console.WriteLine($"Clé     : {key}\n");

        msg = msg.ToLower();
        key = key.ToLower();
        int idx = 0;

        foreach (char c in msg)
        {
            if (c >= 'a' && c <= 'z')
            {
                char lettreCle = key[idx % key.Length];
                int ligne = lettreCle - 'a';
                int colonne = c - 'a';
                char crypte = grille[ligne, colonne];

                Console.WriteLine($"  '{c}' → '{lettreCle}' → '{crypte}'");
                idx++;
            }
        }
        Console.WriteLine();
    }

    public void VoirDecryptage(string msg, string key)
    {
        Console.WriteLine($"Message crypté : {msg}");
        Console.WriteLine($"Clé            : {key}\n");

        msg = msg.ToLower();
        key = key.ToLower();
        int idx = 0;

        foreach (char c in msg)
        {
            if (c >= 'a' && c <= 'z')
            {
                char lettreCle = key[idx % key.Length];
                int ligne = lettreCle - 'a';
                int colonne = -1;

                for (int col = 0; col < grille.GetLength(0); col++)
                {
                    if (grille[ligne, col] == c)
                    {
                        colonne = col;
                        break;
                    }
                }

                char clair = (char)('a' + colonne);
                Console.WriteLine($"  '{c}' → '{lettreCle}' → '{clair}'");
                idx++;
            }
        }
        Console.WriteLine();
    }

    public string DonnerMessageCrypte()
    {
        if (string.IsNullOrEmpty(message) || string.IsNullOrEmpty(cle))
        {
            Console.WriteLine("Erreur : message ou clé non défini(e)");
            return "";
        }

        string crypte = "";
        int idx = 0;

        foreach (char c in message)
        {
            if (c >= 'a' && c <= 'z')
            {
                char lettre = cle[idx % cle.Length];
                int ligne = lettre - 'a';
                int colonne = c - 'a';
                crypte += grille[ligne, colonne];
                idx++;
            }
            else
            {
                crypte += c;
            }
        }

        return crypte;
    }

    public string DonnerMessageClair()
    {
        if (string.IsNullOrEmpty(message) || string.IsNullOrEmpty(cle))
        {
            Console.WriteLine("Erreur : message ou clé non défini(e)");
            return "";
        }

        string clair = "";
        int idx = 0;

        foreach (char c in message)
        {
            if (c >= 'a' && c <= 'z')
            {
                char lettre = cle[idx % cle.Length];
                int ligne = lettre - 'a';

                for (int col = 0; col < grille.GetLength(0); col++)
                {
                    if (grille[ligne, col] == c)
                    {
                        clair += (char)('a' + col);
                        break;
                    }
                }
                idx++;
            }
            else
            {
                clair += c;
            }
        }

        return clair;
    }
}